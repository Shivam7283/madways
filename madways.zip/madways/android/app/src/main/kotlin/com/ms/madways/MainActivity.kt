package com.ms.madways

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
