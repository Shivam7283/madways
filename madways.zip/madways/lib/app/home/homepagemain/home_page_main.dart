//import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class HomePageMain extends StatefulWidget {
  @override
  _HomePageMainState createState() => _HomePageMainState();
}

class _HomePageMainState extends State<HomePageMain> {
  List<String> imgUrls = [
    "https://pbs.twimg.com/media/FpfXenFXwAAtnFU?format=png&name=medium",
    "https://pbs.twimg.com/media/FpeHfMFaMAAKQPI?format=jpg&name=medium",
    "https://pbs.twimg.com/media/FpfObmkWcAA5Zv6?format=jpg&name=large",
    "https://pbs.twimg.com/media/FpeCcXZaYAAwWwt?format=jpg&name=large",
  ];

  @override
  void initState() {
    // TODO: implement initState
    WidgetsBinding.instance.addPostFrameCallback((_) {
      imgUrls.forEach((url) {
        precacheImage(NetworkImage(url), context);
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        centerTitle: true,
        elevation: 2.0,
      ),
      // body: _buildContents(context),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          primary: true,
          child: Container(
            child: Column(
              children: [
                // Container(
                //   color: Colors.white,
                //   height: 180,
                //   child: ListView(
                //     children: [
                //       Image(
                //         image: AssetImage(
                //           'images/mad.jpg',
                //         ),
                //         height: 150,
                //       ),
                //     ],
                //   ),
                // ),
                // Container(
                //   color: Colors.white,
                //   child: CarouselSlider.builder(
                //     itemCount: imgUrls.length,
                //     itemBuilder: (context, index, _) {
                //       return Container(
                //         decoration: BoxDecoration(shape: BoxShape.circle),
                //         margin: EdgeInsets.symmetric(horizontal: 5),
                //         child: Image.network(
                //           imgUrls[index],
                //           fit: BoxFit.fill,
                //           width: 1000,
                //         ),
                //       );
                //     },
                //     options: CarouselOptions(
                //         aspectRatio: 2.0,
                //         autoPlay: true,
                //         animateToClosest: true),
                //   ),
                // ),

                SizedBox(
                  height: 5.0,
                ),
                Container(
                  height: MediaQuery.of(context).size.height,
                  child: ListView(
                    //physics: const AlwaysScrollableScrollPhysics(),
                    children: <Widget>[
                      ListTile(
                        tileColor: Colors.blueGrey,
                        title: Text(
                          "Semester 1",
                          style: TextStyle(color: Colors.white),
                        ),
                        leading: Icon(Icons.sticky_note_2_outlined,
                            color: Colors.white),
                        trailing:
                            Icon(Icons.chevron_right, color: Colors.white),
                        onTap: () {
                          // Navigator.push(
                          //     context,
                          //     MaterialPageRoute(
                          //       builder: (context) => Sem1Subject(),
                          //     ));
                        },
                        //onTap: showSnackBar("Not ready to use", context),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(30.0),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 8.0,
                      ),
                      ListTile(
                        tileColor: Colors.blueGrey,
                        title: Text(
                          "Semester 2",
                          style: TextStyle(color: Colors.white),
                        ),
                        leading: Icon(Icons.sticky_note_2_outlined,
                            color: Colors.white),
                        trailing: Icon(
                          Icons.chevron_right,
                          color: Colors.white,
                        ),
                        onTap: () {
                          // Navigator.push(
                          //     context,
                          //     MaterialPageRoute(
                          //       builder: (context) => Sem2Subject(),
                          //     ));
                        },
                        //onTap: showSnackBar("Not ready to use", context),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(30.0),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 8.0,
                      ),
                      ListTile(
                        tileColor: Colors.blueGrey,
                        title: Text(
                          "Semester 3",
                          style: TextStyle(color: Colors.white),
                        ),
                        leading: Icon(
                          Icons.sticky_note_2_outlined,
                          color: Colors.white,
                        ),
                        trailing: Icon(
                          Icons.chevron_right,
                          color: Colors.white,
                        ),
                        onTap: () {
                          // Navigator.push(
                          //     context,
                          //     MaterialPageRoute(
                          //       builder: (context) => Sem3Subject(),
                          //     ));
                        },
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(30.0),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 8.0,
                      ),
                      ListTile(
                        tileColor: Colors.blueGrey,
                        title: Text(
                          "Semester 4",
                          style: TextStyle(color: Colors.white),
                        ),
                        leading: Icon(Icons.sticky_note_2_outlined,
                            color: Colors.white),
                        trailing:
                            Icon(Icons.chevron_right, color: Colors.white),
                        onTap: () {
                          // Navigator.push(
                          //     context,
                          //     MaterialPageRoute(
                          //       builder: (context) => Sem4Subject(),
                          //     ));
                        },
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(30.0),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 8.0,
                      ),
                      ListTile(
                        tileColor: Colors.blueGrey,
                        title: Text(
                          "Semester 5",
                          style: TextStyle(color: Colors.white),
                        ),
                        leading: Icon(Icons.sticky_note_2_outlined,
                            color: Colors.white),
                        trailing:
                            Icon(Icons.chevron_right, color: Colors.white),
                        onTap: () {
                          // Navigator.push(
                          //     context,
                          //     MaterialPageRoute(
                          //       builder: (context) => Sem5Subject(),
                          //     ));
                        },
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(30.0),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 8.0,
                      ),
                      ListTile(
                        tileColor: Colors.blueGrey,
                        title: Text("Semester 6",
                            style: TextStyle(color: Colors.white)),
                        leading: Icon(Icons.sticky_note_2_outlined,
                            color: Colors.white),
                        trailing:
                            Icon(Icons.chevron_right, color: Colors.white),
                        onTap: () {
                          // Navigator.push(
                          //     context,
                          //     MaterialPageRoute(
                          //       builder: (context) => Sem6Subject(),
                          //     ));
                        },
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(30.0),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 8.0,
                      ),
                      // ListTile(
                      //   tileColor: Colors.blueGrey,
                      //   title: Text("Semester 7",
                      //       style: TextStyle(color: Colors.white)),
                      //   leading: Icon(Icons.sticky_note_2_outlined,
                      //       color: Colors.white),
                      //   trailing:
                      //       Icon(Icons.chevron_right, color: Colors.white),
                      //   onTap: () {
                      //     Navigator.push(
                      //       context,
                      //       MaterialPageRoute(
                      //         builder: (context) => Sem7Subject(),
                      //       ),
                      //     );
                      //   },
                      //   shape: RoundedRectangleBorder(
                      //     borderRadius: BorderRadius.all(
                      //       Radius.circular(30.0),
                      //     ),
                      //   ),
                      // ),
                      // SizedBox(
                      //   height: 8.0,
                      // ),
                      //Sem 8
                      Visibility(
                        visible: false,
                        child: ListTile(
                          tileColor: Colors.grey,
                          title: Text("Semester 8"),
                          leading: Icon(Icons.alarm_on_rounded),
                          trailing: Icon(Icons.forward),
                          // onTap: () {
                          //   Navigator.push(
                          //       context,
                          //       MaterialPageRoute(
                          //         builder: (context) => sem8DMEpapers(),
                          //       ));
                          // },
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(30.0),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 300.0,
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
//   Widget _buildContents(BuildContext context) {
//     final bloc = Provider.of<EntriesBloc>(context, listen: false);
//     return StreamBuilder<List<EntriesListTileModel>>(
//       stream: bloc.entriesTileModelStream,
//       builder: (context, snapshot) {
//         return ListItemBuilder<EntriesListTileModel>(
//           snapshot: snapshot,
//           itemBuilder: (context, model) => EntriesListTile(model: model),
//         );
//       },
//     );
//   }
// }
